<?php
session_start(); 
?>
<html>
<head>
<title>Projects_Tasks_1add</title>
<script src="dat/js/jquery-3.6.0.min.js"></script>
<style>
.ocultar {
    display: none;
}
.mostrar {
    display: block;
}
</style> 
<script>
function verificarPasswords() {
    pass1 = document.getElementById("pass1");
    pass2 = document.getElementById("pass2");
    if (pass1.value != pass2.value) {
        document.getElementById("error").classList.add("mostrar");
         return false;
    } else {
         document.getElementById("error").classList.remove("mostrar");
         document.getElementById("ok").classList.remove("ocultar");
         document.getElementById("login").disabled = true;
        setTimeout(function() {
            location.reload();
        }, 3000);
        return true;
    }
}
</script> 
  
<?php 
include 'db.php'; 

/*
$IdProjects_Tasks = utf8_decode($_GET['IdProjects_Tasks']); 
$IdDepartments = utf8_decode($_GET['IdDepartments']);

if($_SESSION['IdProjects_Tasks']!=$IdProjects_Tasks)
{
 echo '<a href='index.php' title='Login' class='round'>Login</a>';
  exit;
}*/
 
?></head>
<body>
  

<div> <h2>Projects_Tasks_1</h2> </div> 

<form action="Projects_Tasks_1add2.php" method="GET">
<div class="row mt-1" >
<div class="col">Companies_1: 
<SELECT NAME="selCombo1" SIZE=1 onchange = "this.form.submit()"> 
<OPTION VALUE="0">Choose an option</OPTION>
<?php
include "db.php";
$selCombo1= utf8_decode($_GET['selCombo1']);
$resulta=mysqli_query($db_connection, "SELECT , Country FROM  Companies_1 ");
if (mysqli_num_rows($resulta)>0)
{			  
while ($row =mysqli_fetch_array($resulta))  { 
$ =$row[''];
$Country =$row['Country'];
?>
<OPTION VALUE="<?php echo $; ?>"> <?php echo $Country; ?> </OPTION>
<?php
}
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo1) > 0){
$resulta=mysqli_query($db_connection, "SELECT , Country  FROM  Companies_1  WHERE  = '".$selCombo1."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$ =$row[''];
$Country =$row['Country'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $; ?>"> <?php  echo $Country; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>
</form>
  

<div>
<div>
<h1>REGISTRATION HERE</h1>
<form action="Projects_Tasks_1add.php" method="POST"> 
<p>Name</p>
  <input type='text' name='Name'  placeholder='Name' required>   
<p>Description</p>
  <textarea id='Description' name='Description' rows='7' cols='60'> Description </textarea>   
<p>Subresponsable_external</p>
  <input type='number' name='Subresponsable_external'   placeholder='Subresponsable_external'  required>   
<p>For_whom</p>
  <input type='text' name='For_whom'  placeholder='For_whom' required>   
<p>For_whom_id</p>
  <input type='number' name='For_whom_id'   placeholder='For_whom_id'  required>   
<p>Who_will_do_it</p>
  <input type='text' name='Who_will_do_it'  placeholder='Who_will_do_it' required>   
<p>Who_will_do_it_id</p>
  <input type='number' name='Who_will_do_it_id'   placeholder='Who_will_do_it_id'  required>   
<p>Who_waits_for_him</p>
  <input type='text' name='Who_waits_for_him'  placeholder='Who_waits_for_him' required>   
<p>Who_waits_for_him_id</p>
  <input type='number' name='Who_waits_for_him_id'   placeholder='Who_waits_for_him_id'  required>   
<p>Introduction_date</p>
  <input type='datetime' name='Introduction_date' placeholder='Introduction_date' required>  
<p>Starting_date</p>
  <input type='datetime' name='Starting_date' placeholder='Starting_date' required>  
<p>Retouch_date</p>
  <input type='datetime' name='Retouch_date' placeholder='Retouch_date' required>  
<p>Quantity_of_retouch</p>
  <input type='TEXT' name='Quantity_of_retouch' placeholder='Quantity_of_retouch' required>   
<p>Retouch_date_employee</p>
  <input type='datetime' name='Retouch_date_employee' placeholder='Retouch_date_employee' required>  
<p>Quantity_of_retouch_employee</p>
  <input type='TEXT' name='Quantity_of_retouch_employee' placeholder='Quantity_of_retouch_employee' required>   
<p>Internal_death_line_date</p>
  <input type='datetime' name='Internal_death_line_date' placeholder='Internal_death_line_date' required>  
<p>External_death_line_date</p>
  <input type='datetime' name='External_death_line_date' placeholder='External_death_line_date' required>  
<p>Date_waiting</p>
  <input type='datetime' name='Date_waiting' placeholder='Date_waiting' required>  
<p>Date_finish_work</p>
  <input type='datetime' name='Date_finish_work' placeholder='Date_finish_work' required>  
<p>Link</p>
  <input type='text' name='Link'  placeholder='Link' required>   
<p>Commentary_information</p>
  <textarea id='Commentary_information' name='Commentary_information' rows='7' cols='60'> Commentary_information </textarea>   
<p>Date_registration</p>
  <input type='datetime' name='Date_registration' placeholder='Date_registration' required>  
<p>Type_pt</p>
  <input type='number' name='Type_pt'   placeholder='Type_pt'  required>   
<p>Status_project</p>
  <input type='number' name='Status_project'   placeholder='Status_project'  required>   

  <input type='hidden' name='IdDepartments'   value='<?php echo utf8_decode($_GET['selCombo1']); ?>' >   
<p>IdUser</p>
  <input type='number' name='IdUser'   placeholder='IdUser'  required>   

<input type="submit" name="" value="Login">          
</form> 
</div>
</div><a href="index.php?<?php echo $IdProjects_Tasks; ?>">Back</a>

<p>© jimmyvillatoro77@gmail.com</p>
</body>
</html>
 
