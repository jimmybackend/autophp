<?php
session_start(); 
?>
<html>
<head>
<link href="dat/css/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="dat/js/tablecloth.js"></script>
<title>Projects_Tasks_1sel</title>
<style>
    .div-1 {
      background-color: #EBEBEB;
    }
     #products-table
{
     width: 200px;
    height: 400px;
    overflow:scroll;
}
</style>
  
</head>
<body>
  
<div> <h2>Projects_Tasks_1</h2> </div> 
 
<div id='container'>
<h1>Select</h1>
<div class='div-1' style='width:1200px; height:600px; overflow:auto;'>
<div id='content'><table>
  <tr><th>IdProjects_Tasks</th> 
<th>Name</th> 
<th>Description</th> 
<th>Subresponsable_external</th> 
<th>For_whom</th> 
<th>For_whom_id</th> 
<th>Who_will_do_it</th> 
<th>Who_will_do_it_id</th> 
<th>Who_waits_for_him</th> 
<th>Who_waits_for_him_id</th> 
<th>Introduction_date</th> 
<th>Starting_date</th> 
<th>Retouch_date</th> 
<th>Quantity_of_retouch</th> 
<th>Retouch_date_employee</th> 
<th>Quantity_of_retouch_employee</th> 
<th>Internal_death_line_date</th> 
<th>External_death_line_date</th> 
<th>Date_waiting</th> 
<th>Date_finish_work</th> 
<th>Link</th> 
<th>Commentary_information</th> 
<th>Date_registration</th> 
<th>Type_pt</th> 
<th>Status_project</th> 
<th>IdDepartments</th> 
<th>IdUser</th> 

<?php
include 'db.php'; 
$Name= utf8_decode($_GET['Name']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM Projects_Tasks_1 " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$IdProjects_Tasks=$row['IdProjects_Tasks'];
$Name=$row['Name'];
$Description=$row['Description'];
$Subresponsable_external=$row['Subresponsable_external'];
$For_whom=$row['For_whom'];
$For_whom_id=$row['For_whom_id'];
$Who_will_do_it=$row['Who_will_do_it'];
$Who_will_do_it_id=$row['Who_will_do_it_id'];
$Who_waits_for_him=$row['Who_waits_for_him'];
$Who_waits_for_him_id=$row['Who_waits_for_him_id'];
$Introduction_date=$row['Introduction_date'];
$Starting_date=$row['Starting_date'];
$Retouch_date=$row['Retouch_date'];
$Quantity_of_retouch=$row['Quantity_of_retouch'];
$Retouch_date_employee=$row['Retouch_date_employee'];
$Quantity_of_retouch_employee=$row['Quantity_of_retouch_employee'];
$Internal_death_line_date=$row['Internal_death_line_date'];
$External_death_line_date=$row['External_death_line_date'];
$Date_waiting=$row['Date_waiting'];
$Date_finish_work=$row['Date_finish_work'];
$Link=$row['Link'];
$Commentary_information=$row['Commentary_information'];
$Date_registration=$row['Date_registration'];
$Type_pt=$row['Type_pt'];
$Status_project=$row['Status_project'];
$IdDepartments=$row['IdDepartments'];
$IdUser=$row['IdUser'];
 ?>
</tr><tr><td><?php echo $IdProjects_Tasks; ?></td> 
<td><?php echo $Name; ?></td> 
<td><?php echo $Description; ?></td> 
<td><?php echo $Subresponsable_external; ?></td> 
<td><?php echo $For_whom; ?></td> 
<td><?php echo $For_whom_id; ?></td> 
<td><?php echo $Who_will_do_it; ?></td> 
<td><?php echo $Who_will_do_it_id; ?></td> 
<td><?php echo $Who_waits_for_him; ?></td> 
<td><?php echo $Who_waits_for_him_id; ?></td> 
<td><?php echo $Introduction_date; ?></td> 
<td><?php echo $Starting_date; ?></td> 
<td><?php echo $Retouch_date; ?></td> 
<td><?php echo $Quantity_of_retouch; ?></td> 
<td><?php echo $Retouch_date_employee; ?></td> 
<td><?php echo $Quantity_of_retouch_employee; ?></td> 
<td><?php echo $Internal_death_line_date; ?></td> 
<td><?php echo $External_death_line_date; ?></td> 
<td><?php echo $Date_waiting; ?></td> 
<td><?php echo $Date_finish_work; ?></td> 
<td><?php echo $Link; ?></td> 
<td><?php echo $Commentary_information; ?></td> 
<td><?php echo $Date_registration; ?></td> 
<td><?php echo $Type_pt; ?></td> 
<td><?php echo $Status_project; ?></td> 
<td><?php echo $IdDepartments; ?></td> 
<td><?php echo $IdUser; ?></td> 
 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></div></br><a href="index.php?<?php echo $IdProjects_Tasks; ?>">Back</a>

<p>© jimmyvillatoro77@gmail.com</p>
</body>
</html>
  
