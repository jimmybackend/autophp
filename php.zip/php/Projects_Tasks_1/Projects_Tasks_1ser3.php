<?php 
include 'db.php'; 

/*
$IdProjects_Tasks = $_REQUEST['IdProjects_Tasks'];
$IdDepartments = $_REQUEST['IdDepartments'];
*/
 
$html="";
$busca= $_REQUEST["txtbusca"];
$html.="<h2><strong class='cur'>Resultados</h2>";
 
$resultado=mysqli_query($db_connection, "SELECT * FROM Projects_Tasks_1 WHERE Name LIKE '%".$busca."%'" );  
if (mysqli_num_rows($resultado)>0) {
while ($row =mysqli_fetch_array($resultado)) { 
$IdProjects_Tasks=$row['IdProjects_Tasks'];
$html.= '<p><a href=Projects_Tasks_1upd2.php?IdProjects_Tasks='.$IdProjects_Tasks.'>'.$IdProjects_Tasks.'</a><p></b>';$html.= '<p>'.$IdProjects_Tasks.'</p></b>'; 
$Name=$row['Name'];
$html.= '<p>'.$Name.'</p></b>'; 
$Description=$row['Description'];
$html.= '<p>'.$Description.'</p></b>'; 
$Subresponsable_external=$row['Subresponsable_external'];
$html.= '<p>'.$Subresponsable_external.'</p></b>'; 
$For_whom=$row['For_whom'];
$html.= '<p>'.$For_whom.'</p></b>'; 
$For_whom_id=$row['For_whom_id'];
$html.= '<p>'.$For_whom_id.'</p></b>'; 
$Who_will_do_it=$row['Who_will_do_it'];
$html.= '<p>'.$Who_will_do_it.'</p></b>'; 
$Who_will_do_it_id=$row['Who_will_do_it_id'];
$html.= '<p>'.$Who_will_do_it_id.'</p></b>'; 
$Who_waits_for_him=$row['Who_waits_for_him'];
$html.= '<p>'.$Who_waits_for_him.'</p></b>'; 
$Who_waits_for_him_id=$row['Who_waits_for_him_id'];
$html.= '<p>'.$Who_waits_for_him_id.'</p></b>'; 
$Introduction_date=$row['Introduction_date'];
$html.= '<p>'.$Introduction_date.'</p></b>'; 
$Starting_date=$row['Starting_date'];
$html.= '<p>'.$Starting_date.'</p></b>'; 
$Retouch_date=$row['Retouch_date'];
$html.= '<p>'.$Retouch_date.'</p></b>'; 
$Quantity_of_retouch=$row['Quantity_of_retouch'];
$html.= '<p>'.$Quantity_of_retouch.'</p></b>'; 
$Retouch_date_employee=$row['Retouch_date_employee'];
$html.= '<p>'.$Retouch_date_employee.'</p></b>'; 
$Quantity_of_retouch_employee=$row['Quantity_of_retouch_employee'];
$html.= '<p>'.$Quantity_of_retouch_employee.'</p></b>'; 
$Internal_death_line_date=$row['Internal_death_line_date'];
$html.= '<p>'.$Internal_death_line_date.'</p></b>'; 
$External_death_line_date=$row['External_death_line_date'];
$html.= '<p>'.$External_death_line_date.'</p></b>'; 
$Date_waiting=$row['Date_waiting'];
$html.= '<p>'.$Date_waiting.'</p></b>'; 
$Date_finish_work=$row['Date_finish_work'];
$html.= '<p>'.$Date_finish_work.'</p></b>'; 
$Link=$row['Link'];
$html.= '<p>'.$Link.'</p></b>'; 
$Commentary_information=$row['Commentary_information'];
$html.= '<p>'.$Commentary_information.'</p></b>'; 
$Date_registration=$row['Date_registration'];
$html.= '<p>'.$Date_registration.'</p></b>'; 
$Type_pt=$row['Type_pt'];
$html.= '<p>'.$Type_pt.'</p></b>'; 
$Status_project=$row['Status_project'];
$html.= '<p>'.$Status_project.'</p></b>'; 
$IdDepartments=$row['IdDepartments'];
$html.= '<p>'.$IdDepartments.'</p></b>'; 
$IdUser=$row['IdUser'];
$html.= '<p>'.$IdUser.'</p></b>'; 
}
$html.="</b>";
echo $html;
}else
echo 
"Is not found";

mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
