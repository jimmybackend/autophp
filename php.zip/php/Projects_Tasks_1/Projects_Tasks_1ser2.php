<?php
session_start(); 
?>
<html>
<head>
<title>Projects_Tasks_1ser</title>
  

<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "Projects_Tasks_1ser.php?IdProjects_Tasks=<?php echo $IdProjects_Tasks?>",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>
 
 
<?php
include 'db.php'; 
$IdProjects_Tasks= utf8_decode($_GET['IdProjects_Tasks']); 
$IdDepartments = utf8_decode($_GET['IdDepartments']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM Projects_Tasks_1 WHERE IdProjects_Tasks = '".$IdProjects_Tasks."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$IdProjects_Tasks=$row['IdProjects_Tasks'];
$Name=$row['Name'];
$Description=$row['Description'];
$Subresponsable_external=$row['Subresponsable_external'];
$For_whom=$row['For_whom'];
$For_whom_id=$row['For_whom_id'];
$Who_will_do_it=$row['Who_will_do_it'];
$Who_will_do_it_id=$row['Who_will_do_it_id'];
$Who_waits_for_him=$row['Who_waits_for_him'];
$Who_waits_for_him_id=$row['Who_waits_for_him_id'];
$Introduction_date=$row['Introduction_date'];
$Starting_date=$row['Starting_date'];
$Retouch_date=$row['Retouch_date'];
$Quantity_of_retouch=$row['Quantity_of_retouch'];
$Retouch_date_employee=$row['Retouch_date_employee'];
$Quantity_of_retouch_employee=$row['Quantity_of_retouch_employee'];
$Internal_death_line_date=$row['Internal_death_line_date'];
$External_death_line_date=$row['External_death_line_date'];
$Date_waiting=$row['Date_waiting'];
$Date_finish_work=$row['Date_finish_work'];
$Link=$row['Link'];
$Commentary_information=$row['Commentary_information'];
$Date_registration=$row['Date_registration'];
$Type_pt=$row['Type_pt'];
$Status_project=$row['Status_project'];
$IdDepartments=$row['IdDepartments'];
$IdUser=$row['IdUser'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
 
 
 <?php  
$Name = utf8_decode($_GET['Name']); 
?> 
</head>
<body>
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
  
 
<div> <h2>Projects_Tasks_1</h2> </div> 
 

<h2>busca por <strong class="cur">Name</strong></h2>
<form action="Projects_Tasks_1ser.php" method="POST">
<div class="input-group mb-3">
<input type="hidden" name="IdProjects_Tasks" value="<?php echo utf8_decode($_GET['IdProjects_Tasks']); ?>">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $Name; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div>
</form>  
 
<a href="index.php?<?php echo $IdProjects_Tasks; ?>">Back</a>

<p>© jimmyvillatoro77@gmail.com</p>
</body>
</html>
  
