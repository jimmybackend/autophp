<?php 
include 'db.php'; 

/*
$IdProjects_Tasks = $_REQUEST['IdProjects_Tasks'];
$IdDepartments = $_REQUEST['IdDepartments'];
*/
 
$IdProjects_Tasks= $_REQUEST['IdProjects_Tasks'];
$Name= $_REQUEST['Name'];
$Description= $_REQUEST['Description'];
$Subresponsable_external= $_REQUEST['Subresponsable_external'];
$For_whom= $_REQUEST['For_whom'];
$For_whom_id= $_REQUEST['For_whom_id'];
$Who_will_do_it= $_REQUEST['Who_will_do_it'];
$Who_will_do_it_id= $_REQUEST['Who_will_do_it_id'];
$Who_waits_for_him= $_REQUEST['Who_waits_for_him'];
$Who_waits_for_him_id= $_REQUEST['Who_waits_for_him_id'];
$Introduction_date= $_REQUEST['Introduction_date'];
$Starting_date= $_REQUEST['Starting_date'];
$Retouch_date= $_REQUEST['Retouch_date'];
$Quantity_of_retouch= $_REQUEST['Quantity_of_retouch'];
$Retouch_date_employee= $_REQUEST['Retouch_date_employee'];
$Quantity_of_retouch_employee= $_REQUEST['Quantity_of_retouch_employee'];
$Internal_death_line_date= $_REQUEST['Internal_death_line_date'];
$External_death_line_date= $_REQUEST['External_death_line_date'];
$Date_waiting= $_REQUEST['Date_waiting'];
$Date_finish_work= $_REQUEST['Date_finish_work'];
$Link= $_REQUEST['Link'];
$Commentary_information= $_REQUEST['Commentary_information'];
$Date_registration= $_REQUEST['Date_registration'];
$Type_pt= $_REQUEST['Type_pt'];
$Status_project= $_REQUEST['Status_project'];
$IdDepartments= $_REQUEST['IdDepartments'];
$IdUser= $_REQUEST['IdUser'];
$Idx= $_REQUEST['Idx'];
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $dt= $date." ". $time;  
$resultado=mysqli_query($db_connection, "SELECT * FROM Projects_Tasks_1 WHERE IdProjects_Tasks LIKE '".$Idx."'" );  
if (mysqli_num_rows($resultado)>0) {
$delete_value ="DELETE FROM Projects_Tasks_1 WHERE IdProjects_Tasks LIKE '".$Idx."'";  
$retry_value = mysqli_query($db_connection,$delete_value);
 header("Location: index.php"); 
mysqli_free_result($retry_value);

 header("Location: index.php");}
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>