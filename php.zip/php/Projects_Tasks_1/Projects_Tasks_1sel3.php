<?php
session_start(); 
?>
<html>
<head>
<link href="dat/css/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="dat/js/tablecloth.js"></script>
<title>Projects_Tasks_1sel</title>
<style>
    .div-1 {
      background-color: #EBEBEB;
    }
     #products-table
{
     width: 200px;
    height: 400px;
    overflow:scroll;
}
</style>
  
</head>
<body>
  

<div> <h2>Projects_Tasks_1</h2> </div> 
 
<div id='container'>
	<h1>Select for Edit</h1>
<div class='div-1' style='width:1200px; height:600px; overflow:auto;'>
<div id='content'><table>
  <tr><th>Edit</th><th>IdProjects_Tasks</th> 
<th>Name</th> 
<th>Description</th> 
<th>Subresponsable_external</th> 
<th>For_whom</th> 
<th>For_whom_id</th> 
<th>Who_will_do_it</th> 
<th>Who_will_do_it_id</th> 
<th>Who_waits_for_him</th> 
<th>Who_waits_for_him_id</th> 
<th>Introduction_date</th> 
<th>Starting_date</th> 
<th>Retouch_date</th> 
<th>Quantity_of_retouch</th> 
<th>Retouch_date_employee</th> 
<th>Quantity_of_retouch_employee</th> 
<th>Internal_death_line_date</th> 
<th>External_death_line_date</th> 
<th>Date_waiting</th> 
<th>Date_finish_work</th> 
<th>Link</th> 
<th>Commentary_information</th> 
<th>Date_registration</th> 
<th>Type_pt</th> 
<th>Status_project</th> 
<th>IdDepartments</th> 
<th>IdUser</th> 

<?php
include 'db.php'; 
$Name= utf8_decode($_GET['Name']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM Projects_Tasks_1 " );
while ($row =mysqli_fetch_array($resultado)) 
{  
$IdProjects_Tasks=$row['IdProjects_Tasks'];
$Name=$row['Name'];
$Description=$row['Description'];
$Subresponsable_external=$row['Subresponsable_external'];
$For_whom=$row['For_whom'];
$For_whom_id=$row['For_whom_id'];
$Who_will_do_it=$row['Who_will_do_it'];
$Who_will_do_it_id=$row['Who_will_do_it_id'];
$Who_waits_for_him=$row['Who_waits_for_him'];
$Who_waits_for_him_id=$row['Who_waits_for_him_id'];
$Introduction_date=$row['Introduction_date'];
$Starting_date=$row['Starting_date'];
$Retouch_date=$row['Retouch_date'];
$Quantity_of_retouch=$row['Quantity_of_retouch'];
$Retouch_date_employee=$row['Retouch_date_employee'];
$Quantity_of_retouch_employee=$row['Quantity_of_retouch_employee'];
$Internal_death_line_date=$row['Internal_death_line_date'];
$External_death_line_date=$row['External_death_line_date'];
$Date_waiting=$row['Date_waiting'];
$Date_finish_work=$row['Date_finish_work'];
$Link=$row['Link'];
$Commentary_information=$row['Commentary_information'];
$Date_registration=$row['Date_registration'];
$Type_pt=$row['Type_pt'];
$Status_project=$row['Status_project'];
$IdDepartments=$row['IdDepartments'];
$IdUser=$row['IdUser'];
 ?>
</tr><tr><tr><form action="Projects_Tasks_1upd3.php" method="POST"> 
<input type='hidden' name='IdProjects_Tasks' value='<?php echo utf8_decode($_GET['IdProjects_Tasks']); ?>'> 
<input type='hidden' name='IdDepartments' value='<?php echo utf8_decode($_GET['IdDepartments']); ?>'> 
 
<td><div><button type='submit' class='btn btn-success'>Edit</button> </div></td> 
<td><div><input type='number' name='IdProjects_Tasks'  placeholder='IdProjects_Tasks' value='<?php echo $IdProjects_Tasks; ?>' required> </div></td>  
 
<td><div><input type='text' name='Name'   placeholder='Name' value='<?php echo $Name; ?>' required> </div></td>  
 
<td><div><textarea id='Description' name='Description' rows='10' cols='100'> <?php echo $Description; ?> </textarea> </div></td>  
 
<td><div><input type='number' name='Subresponsable_external'  placeholder='Subresponsable_external' value='<?php echo $Subresponsable_external; ?>' required> </div></td>  
 
<td><div><input type='text' name='For_whom'   placeholder='For_whom' value='<?php echo $For_whom; ?>' required> </div></td>  
 
<td><div><input type='number' name='For_whom_id'  placeholder='For_whom_id' value='<?php echo $For_whom_id; ?>' required> </div></td>  
 
<td><div><input type='text' name='Who_will_do_it'   placeholder='Who_will_do_it' value='<?php echo $Who_will_do_it; ?>' required> </div></td>  
 
<td><div><input type='number' name='Who_will_do_it_id'  placeholder='Who_will_do_it_id' value='<?php echo $Who_will_do_it_id; ?>' required> </div></td>  
 
<td><div><input type='text' name='Who_waits_for_him'   placeholder='Who_waits_for_him' value='<?php echo $Who_waits_for_him; ?>' required> </div></td>  
 
<td><div><input type='number' name='Who_waits_for_him_id'  placeholder='Who_waits_for_him_id' value='<?php echo $Who_waits_for_him_id; ?>' required> </div></td>  
 
<td><div><input type='datetime-local' name='Introduction_date' placeholder='Introduction_date' value='<?php echo $Introduction_date; ?>' required> </div></td>  
 
<td><div><input type='datetime-local' name='Starting_date' placeholder='Starting_date' value='<?php echo $Starting_date; ?>' required> </div></td>  
 
<td><div><input type='datetime-local' name='Retouch_date' placeholder='Retouch_date' value='<?php echo $Retouch_date; ?>' required> </div></td>  
 
<td><div><input type='TEXT' name='Quantity_of_retouch'  placeholder='Quantity_of_retouch' value='<?php echo $Quantity_of_retouch; ?>' required> </div></td>  
 
<td><div><input type='datetime-local' name='Retouch_date_employee' placeholder='Retouch_date_employee' value='<?php echo $Retouch_date_employee; ?>' required> </div></td>  
 
<td><div><input type='TEXT' name='Quantity_of_retouch_employee'  placeholder='Quantity_of_retouch_employee' value='<?php echo $Quantity_of_retouch_employee; ?>' required> </div></td>  
 
<td><div><input type='datetime-local' name='Internal_death_line_date' placeholder='Internal_death_line_date' value='<?php echo $Internal_death_line_date; ?>' required> </div></td>  
 
<td><div><input type='datetime-local' name='External_death_line_date' placeholder='External_death_line_date' value='<?php echo $External_death_line_date; ?>' required> </div></td>  
 
<td><div><input type='datetime-local' name='Date_waiting' placeholder='Date_waiting' value='<?php echo $Date_waiting; ?>' required> </div></td>  
 
<td><div><input type='datetime-local' name='Date_finish_work' placeholder='Date_finish_work' value='<?php echo $Date_finish_work; ?>' required> </div></td>  
 
<td><div><input type='text' name='Link'   placeholder='Link' value='<?php echo $Link; ?>' required> </div></td>  
 
<td><div><textarea id='Commentary_information' name='Commentary_information' rows='10' cols='100'> <?php echo $Commentary_information; ?> </textarea> </div></td>  
 
<td><div><input type='datetime-local' name='Date_registration' placeholder='Date_registration' value='<?php echo $Date_registration; ?>' required> </div></td>  
 
<td><div><input type='number' name='Type_pt'  placeholder='Type_pt' value='<?php echo $Type_pt; ?>' required> </div></td>  
 
<td><div><input type='number' name='Status_project'  placeholder='Status_project' value='<?php echo $Status_project; ?>' required> </div></td>  
 
<td><div><input type='number' name='IdDepartments'  placeholder='IdDepartments' value='<?php echo $IdDepartments; ?>' required> </div></td>  
 
<td><div><input type='number' name='IdUser'  placeholder='IdUser' value='<?php echo $IdUser; ?>' required> </div></td>  
 
</form> 
 <?php } mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 
</tr></table>	</div>
</div></br></div></br><a href="index.php?<?php echo $IdProjects_Tasks; ?>">Back</a>

<p>© jimmyvillatoro77@gmail.com</p>
</body>
</html>
  
