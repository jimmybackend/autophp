<?php
session_start(); 
?>
<html>
<head>
<title>Projects_Tasks_1del</title>
<script src="dat/js/jquery-3.6.0.min.js"></script>
  
<?php
$IdProjects_Tasks= $_REQUEST['IdProjects_Tasks'];
?>
</head>
<body>
<p>Usuario:<a style="color:orange;"> <?php echo $nombres; ?> </a></p>
  

<div> <h2>Projects_Tasks_1</h2> </div> 
<h1>DELETE</h1>
<form action="Projects_Tasks_1del.php" method="POST"> 
<p>IdProjects_Tasks to Delete</p><input type='text' name='Idx' placeholder='IdProjects_Tasks to Delete' value='<?php echo  $IdProjects_Tasks; ?>' required>  
<input type="submit" name="" value="Delete">
</form>
</div>
</div> 
<a href="index.php?<?php echo $IdProjects_Tasks; ?>">Back</a>

<p>© jimmyvillatoro77@gmail.com</p>
</body>
</html>
  
