<?php
session_start(); 
?>
<html>
<head>
<title>Projects_Tasks_1upd</title>
<script src="dat/js/jquery-3.6.0.min.js"></script>
<style>
.ocultar {
    display: none;
}
.mostrar {
    display: block;
}
</style> 
<script>
function verificarPasswords() {
    pass1 = document.getElementById("pass1");
    pass2 = document.getElementById("pass2");
    if (pass1.value != pass2.value) {
        document.getElementById("error").classList.add("mostrar");
         return false;
    } else {
         document.getElementById("error").classList.remove("mostrar");
         document.getElementById("ok").classList.remove("ocultar");
         document.getElementById("login").disabled = true;
        setTimeout(function() {
            location.reload();
        }, 3000);
        return true;
    }
}
</script> 
  
<?php
include 'db.php'; 
$IdProjects_Tasks= utf8_decode($_GET['IdProjects_Tasks']); 
$IdDepartments = utf8_decode($_GET['IdDepartments']); 
$resultado=mysqli_query($db_connection, "SELECT * FROM Projects_Tasks_1 WHERE IdProjects_Tasks = '".$IdProjects_Tasks."'" ); 
while ($row =mysqli_fetch_array($resultado)) {  
$IdProjects_Tasks=$row['IdProjects_Tasks'];
$Name=$row['Name'];
$Description=$row['Description'];
$Subresponsable_external=$row['Subresponsable_external'];
$For_whom=$row['For_whom'];
$For_whom_id=$row['For_whom_id'];
$Who_will_do_it=$row['Who_will_do_it'];
$Who_will_do_it_id=$row['Who_will_do_it_id'];
$Who_waits_for_him=$row['Who_waits_for_him'];
$Who_waits_for_him_id=$row['Who_waits_for_him_id'];
$Introduction_date=$row['Introduction_date'];
$Starting_date=$row['Starting_date'];
$Retouch_date=$row['Retouch_date'];
$Quantity_of_retouch=$row['Quantity_of_retouch'];
$Retouch_date_employee=$row['Retouch_date_employee'];
$Quantity_of_retouch_employee=$row['Quantity_of_retouch_employee'];
$Internal_death_line_date=$row['Internal_death_line_date'];
$External_death_line_date=$row['External_death_line_date'];
$Date_waiting=$row['Date_waiting'];
$Date_finish_work=$row['Date_finish_work'];
$Link=$row['Link'];
$Commentary_information=$row['Commentary_information'];
$Date_registration=$row['Date_registration'];
$Type_pt=$row['Type_pt'];
$Status_project=$row['Status_project'];
$IdDepartments=$row['IdDepartments'];
$IdUser=$row['IdUser'];
 } 
 mysqli_free_result($resultado);
mysqli_close($db_connection); 
?> 

<script src="dat/js/jquery-3.6.0.min.js"></script>
<script language=JavaScript>
$(document).ready(function(){
         $("#txtbusca").keyup(function(){
              var parametros="txtbusca="+$(this).val()
              $.ajax({
                    data:  parametros,
                  url:   "Projects_Tasks_1ser3.php",
                  type:  "post",
                    beforeSend: function () { },
                    success:  function (response) {                 
                        $(".salida").html(response);
                  },
                  error:function(){
                       alert("funcion error")
                    }
               });
         })
})
</script>
 
</head>
<body>
  

<div> <h2>Projects_Tasks_1</h2> </div> 
 

<h1>busca por <strong class="cur">Name</strong></h1>
<form action="Projects_Tasks_1upd2.php" method="POST">
<div class="input-group mb-3">
          <input type="text" class="form-control" id="txtbusca" value="<?php echo  $Name; ?>" aria-label="Search" aria-describedby="basic-addon2">
       <div class="input-group-append">
          <span class="input-group-text" id="basic-addon2"></span>
        </div>
</div>
<div class="salida"></div></form>
 
<h1>Companies_1</h1>
<form action="Projects_Tasks_1upd2.php" method="GET">

<input type="hidden" name="IdProjects_Tasks" value="<?php echo utf8_decode($_GET['IdProjects_Tasks']); ?>">

<div class="row mt-1" >
<div class="col">Companies_1: 
<SELECT NAME="selCombo1" SIZE=1 onchange = "this.form.submit()"> 
<OPTION VALUE="0"> Choose an option</OPTION>
<?php
include "db.php";

$selCombo1= utf8_decode($_GET['selCombo1']);
$resulta=mysqli_query($db_connection, "SELECT , Country FROM  Companies_1 ");
if (mysqli_num_rows($resulta)>0)
{			  
while ($row =mysqli_fetch_array($resulta))  { 
$ =$row[''];
$Country =$row['Country'];
?>
<OPTION VALUE="<?php echo $; ?>"> <?php echo $Country; ?> </OPTION>
<?php
      }
if (!$resulta) 
   die("Error: " . mysqli_error());
}
if(strlen($selCombo1) > 0){
$resulta=mysqli_query($db_connection, "SELECT , Country  FROM  Companies_1  WHERE  = '".$selCombo1."'" );
if (mysqli_num_rows($resulta)>0)
      while ($row =mysqli_fetch_array($resulta))  { 
$ =$row[''];
$Country =$row['Country'];
 ?>
<OPTION SELECTED ="selected" VALUE="<?php echo $; ?>"> <?php  echo $Country; ?> </OPTION>
<?php
      }
}
mysqli_free_result($resulta);
mysqli_close($db_connection);
 ?>
</SELECT>  
</div>
</div>
</form>
 
<h1>UPDATE</h1>
<form action="Projects_Tasks_1upd.php" method="POST">

  <input type='hidden' name='IdProjects_Tasks'   value='<?php echo utf8_decode($_GET['IdProjects_Tasks']); ?>' >  

<p>Name</p>
  <input type='text' name='Name' placeholder='Name' value='<?php echo $Name; ?>' required> 

<p>Description</p>
  <textarea id='Description' name='Description' rows='7' cols='60'> <?php echo $Description; ?> </textarea> 

<p>Subresponsable_external</p>
  <input type='number' name='Subresponsable_external'  placeholder='Subresponsable_external'  value='<?php echo $Subresponsable_external; ?>' required> 

<p>For_whom</p>
  <input type='text' name='For_whom' placeholder='For_whom' value='<?php echo $For_whom; ?>' required> 

<p>For_whom_id</p>
  <input type='number' name='For_whom_id'  placeholder='For_whom_id'  value='<?php echo $For_whom_id; ?>' required> 

<p>Who_will_do_it</p>
  <input type='text' name='Who_will_do_it' placeholder='Who_will_do_it' value='<?php echo $Who_will_do_it; ?>' required> 

<p>Who_will_do_it_id</p>
  <input type='number' name='Who_will_do_it_id'  placeholder='Who_will_do_it_id'  value='<?php echo $Who_will_do_it_id; ?>' required> 

<p>Who_waits_for_him</p>
  <input type='text' name='Who_waits_for_him' placeholder='Who_waits_for_him' value='<?php echo $Who_waits_for_him; ?>' required> 

<p>Who_waits_for_him_id</p>
  <input type='number' name='Who_waits_for_him_id'  placeholder='Who_waits_for_him_id'  value='<?php echo $Who_waits_for_him_id; ?>' required> 

<p>Introduction_date</p>
  <input type='datetime' name='Introduction_date'  placeholder='Introduction_date' value='<?php echo $Introduction_date; ?>' required> 

<p>Starting_date</p>
  <input type='datetime' name='Starting_date'  placeholder='Starting_date' value='<?php echo $Starting_date; ?>' required> 

<p>Retouch_date</p>
  <input type='datetime' name='Retouch_date'  placeholder='Retouch_date' value='<?php echo $Retouch_date; ?>' required> 

<p>Quantity_of_retouch</p>
  <input type='TEXT' name='Quantity_of_retouch'  placeholder='Quantity_of_retouch' value='<?php echo $Quantity_of_retouch; ?>' required> 

<p>Retouch_date_employee</p>
  <input type='datetime' name='Retouch_date_employee'  placeholder='Retouch_date_employee' value='<?php echo $Retouch_date_employee; ?>' required> 

<p>Quantity_of_retouch_employee</p>
  <input type='TEXT' name='Quantity_of_retouch_employee'  placeholder='Quantity_of_retouch_employee' value='<?php echo $Quantity_of_retouch_employee; ?>' required> 

<p>Internal_death_line_date</p>
  <input type='datetime' name='Internal_death_line_date'  placeholder='Internal_death_line_date' value='<?php echo $Internal_death_line_date; ?>' required> 

<p>External_death_line_date</p>
  <input type='datetime' name='External_death_line_date'  placeholder='External_death_line_date' value='<?php echo $External_death_line_date; ?>' required> 

<p>Date_waiting</p>
  <input type='datetime' name='Date_waiting'  placeholder='Date_waiting' value='<?php echo $Date_waiting; ?>' required> 

<p>Date_finish_work</p>
  <input type='datetime' name='Date_finish_work'  placeholder='Date_finish_work' value='<?php echo $Date_finish_work; ?>' required> 

<p>Link</p>
  <input type='text' name='Link' placeholder='Link' value='<?php echo $Link; ?>' required> 

<p>Commentary_information</p>
  <textarea id='Commentary_information' name='Commentary_information' rows='7' cols='60'> <?php echo $Commentary_information; ?> </textarea> 

<p>Date_registration</p>
  <input type='datetime' name='Date_registration'  placeholder='Date_registration' value='<?php echo $Date_registration; ?>' required> 

<p>Type_pt</p>
  <input type='number' name='Type_pt'  placeholder='Type_pt'  value='<?php echo $Type_pt; ?>' required> 

<p>Status_project</p>
  <input type='number' name='Status_project'  placeholder='Status_project'  value='<?php echo $Status_project; ?>' required> 


  <input type='hidden' name='IdDepartments'   value='<?php echo utf8_decode($_GET['IdDepartments']); ?>' >  

<p>IdUser</p>
  <input type='number' name='IdUser'  placeholder='IdUser'  value='<?php echo $IdUser; ?>' required> 

<input type="submit" name="" value="Login">
</form>
</div>
</div> 
<a href="index.php?<?php echo $IdProjects_Tasks; ?>">Back</a>

<p>© jimmyvillatoro77@gmail.com</p>
</body>
</html>
  
